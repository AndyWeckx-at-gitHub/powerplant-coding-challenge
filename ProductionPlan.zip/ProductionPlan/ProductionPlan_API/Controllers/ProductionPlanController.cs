﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
//
using ProductionPlan_API.Model;
using ProductionPlan_Lib.Model;

namespace ProductionPlan_API.Controllers
{
    [Route("api/ProductionPlan")]
    [ApiController]
    public class ProductionPlanController : ControllerBase
    {
        #region Private Methods
        private bool ProductionPlanExists(int id)
        {
            return FindProductionPlan(id) != null;
        }
        private ProductionPlan FindProductionPlan(int id)
        {
            return new ProductionPlan() { Id = id };
        }
        #endregion

        #region Exception Handling Middleware (Produce a consistent error payload format in response body)
        [Route("/error-local-development")]
        public IActionResult ErrorLocalDevelopment([FromServices] IWebHostEnvironment webHostEnvironment)
        {
            if (webHostEnvironment.EnvironmentName != "Development")
            {
                throw new InvalidOperationException(
                    "This shouldn't be invoked in non-development environments.");
            }

            var context = HttpContext.Features.Get<IExceptionHandlerFeature>();

            return Problem(
                detail: context.Error.StackTrace,
                title: context.Error.Message);
        }

        [Route("/error")]
        public IActionResult Error() => Problem();
        #endregion

        #region Public Methods
        // GET: api/ProductionPlan
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new List<string>() { "Hello", "GEM-SPaaS" };
        }

        // GET: api/ProductionPlan/5
        [HttpGet("{id}")]
        public ActionResult<ProductionPlan> Get(int id)
        {
            var productionPlan = FindProductionPlan(id);
            if (productionPlan == null)
                return NotFound();

            return productionPlan;
        }

        // POST: api/ProductionPlan
        [HttpPost]
        public ActionResult<IEnumerable<ProductionPlanItem>> Post(Payload payload)
        {
            ProductionPlanManager productionPlanManager = new ProductionPlanManager(payload);
            ProductionPlan productionPlan = productionPlanManager.CalculateProductionPlan();
            return CreatedAtAction(nameof(Get), productionPlan.ProductionPlanItems);
        }

        // PUT: api/ProductionPlan/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, ProductionPlan productionPlan)
        {
            if (id != productionPlan.Id)
                return BadRequest();

            try
            {
                // Save productionPlan
            }
            catch
            {
                if (!ProductionPlanExists(id))
                    return NotFound();
                else
                    throw;
            }

            return NoContent();
        }

        // DELETE: api/ProductionPlan/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var productionPlan = FindProductionPlan(id);
            if (productionPlan == null)
                return NotFound();

            // Delete productionPlan

            return NoContent();
        }
        #endregion
    }
}