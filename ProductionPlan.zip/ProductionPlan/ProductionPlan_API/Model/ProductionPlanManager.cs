﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//
using ProductionPlan_Lib.Model;

namespace ProductionPlan_API.Model
{
    /// <summary>
    /// Business object to calculate productionplan.
    /// </summary>
    public class ProductionPlanManager
    {
        #region Private Constants
        private const string CST_PowerPlantType_GasFired = "gasfired";
        private const string CST_PowerPlantType_Turbojet = "turbojet";
        private const string CST_PowerPlantType_WindTurbine = "windturbine";
        private const double CST_CreatedCo2_GasFired = 0.3;
        private const double CST_CreatedCo2_Turbojet = 0.6;
        private const double CST_CreatedCo2_WindTurbine = 0;
        #endregion
        #region Private Fields
        private Payload _payload;
        #endregion
        #region Private Methods
        private void AssignExternalFactorsToPowerPlant(Powerplant powerplant)
        {
            powerplant.Availabilty = 100;
            if (powerplant.Type.Equals(CST_PowerPlantType_GasFired, StringComparison.OrdinalIgnoreCase))
            {
                powerplant.CostFuel = _payload.Fuels.Gas;
                powerplant.CostCo2 = _payload.Fuels.Co2;
                powerplant.CreatedCo2 = CST_CreatedCo2_GasFired;
            }
            else if (powerplant.Type.Equals(CST_PowerPlantType_Turbojet, StringComparison.OrdinalIgnoreCase))
            {
                powerplant.CostFuel = _payload.Fuels.Kerosine;
                powerplant.CostCo2 = _payload.Fuels.Co2;
                powerplant.CreatedCo2 = CST_CreatedCo2_Turbojet;
            }
            else if (powerplant.Type.Equals(CST_PowerPlantType_WindTurbine, StringComparison.OrdinalIgnoreCase))
            {
                powerplant.Availabilty = _payload.Fuels.Wind;
                powerplant.CostFuel = 0;
                powerplant.CostCo2 = 0;
                powerplant.CreatedCo2 = CST_CreatedCo2_WindTurbine;
            }
        }
        #endregion
        #region Constructors
        public ProductionPlanManager(Payload payload)
        {
            _payload = payload;
        }
        #endregion
        #region Public Methods
        /// <summary>
        /// Calculate the productionPlan.
        /// </summary>
        /// <remarks>
        /// * Rule 1: The sum of the power produced by all the powerplants together MUST equal the load.
        /// * Rule 2: Order powerplants by merit-order
        ///           Those with the lowest costs are the first ones to be brought online to meet demand.
        /// * Special case!
        ///   => After using the TOTAL capacity of the powerplant, the "restpower" to provide is less then the Pmin of the next powerplant.
        ///      The next powerplant will not be used.
        ///   => The result of the production plan will be wrong; the power produced by all the powerplants together will NOT equal the load.
        ///   Solution: To make it possible to use the next powerplant in this special case, we must reserve "next powerplant".Pmin power. 
        ///  
        ///   Example: Payload2: When using the TOTAL capacity of 460 MWh from the gasfiredbig1,  
        ///                      => the gasfiredbig2 can't be used because the "restpower" (20 MWh) is less then the Pmin of the gasfiredbig2 (100 MWh).
        ///                      => the load is not reached: the tj1 is used (16 MWh), but the total produced is 476MWh and not 480MWh.
        ///                      => Solution: use less power (reserve it) from gasfiredbig1 so gasfiredbig2 can be used.
        ///                                   And the load is reached.
        /// </remarks>
        /// <returns>ProductionPlan</returns>
        public ProductionPlan CalculateProductionPlan()
        {
            ProductionPlan productionPlan = new ProductionPlan() 
                { Id = 1, ProductionPlanItems = new List<ProductionPlanItem>(), Result = string.Empty };

            // Calculate cost to generate power for each powerplant
            foreach (Powerplant powerplant in _payload.PowerPlants)
            {
                AssignExternalFactorsToPowerPlant(powerplant);
                powerplant.CostToGeneratePower = 1 / powerplant.Efficiency * powerplant.CostFuel;
                powerplant.CostToGeneratePower += (powerplant.CreatedCo2 * powerplant.CostCo2); // Each MWh generated creates x ton of CO2
            }

            // Order powerplants by merit-order
            // Those with the lowest costs are the first ones to be brought online to meet demand
            _payload.PowerPlants = _payload.PowerPlants.OrderBy(ppl => ppl.CostToGeneratePower).ToList();

            // Calculate how much power each of a multitude of different powerplants need to produce (a.k.a. the production-plan)
            double powerToProvide = _payload.Load;
            for(int idx = 0; idx < _payload.PowerPlants.Count; idx++)
            {
                Powerplant powerplant = _payload.PowerPlants[idx];
                double power = 0;
                if (powerToProvide >= powerplant.Pmin)
                {
                    power = powerToProvide >= powerplant.Pmax * (powerplant.Availabilty / 100) ?
                               powerplant.Pmax * (powerplant.Availabilty / 100) : powerToProvide;

                    // Special case?
                    double restPower = powerToProvide - power;
                    if (idx + 1 < _payload.PowerPlants.Count)  // Is there a next powerplant?
                    {
                        if (restPower > 0 && restPower <= _payload.PowerPlants[idx + 1].Pmin)
                        {
                            if(power >= _payload.PowerPlants[idx + 1].Pmin - restPower ) // Is there enough power to reserve?
                                power -= (_payload.PowerPlants[idx + 1].Pmin - restPower); // Reserve "next powerplant".Pmin power. 
                        }
                    }

                    powerToProvide -= power;
                }
                productionPlan.ProductionPlanItems.Add(new ProductionPlanItem() { Name = powerplant.Name, P = Math.Round(power, 1) });
            }

            // Check result
            if (productionPlan.ProductionPlanItems.Sum(ppi => ppi.P) < _payload.Load)
            {
                string warningMessage = string.Concat("WARNING! Het is niet mogelijk om met de huidige powerplants de load van ",
                                                      _payload.Load.ToString(), " MWh te halen!");
                productionPlan.Result = warningMessage;

                //throw new ArgumentException(warningMessage); // ProductionPlanController will handle exception. (Exception Handling Middleware).
            }

            return productionPlan;
        }
        #endregion
    }
}
