﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
//
using Lib = ProductionPlan_Lib.Model;

namespace ProductionPlan
{
    public partial class MainWindow : Window
    {
        #region Private Constants
        private const string cst_url = "https://localhost:8888/api/productionplan";
        //private const string cst_url = "/api/productionplan";
        #endregion
        #region Private Fields
        private ProductionPlanController _productionPlanController;
        private enumSimulationType _simulationType;
        #endregion
        #region Private Methods
        private void Initialize()
        {
            _simulationType = enumSimulationType.NormalLoad_NormalWeather;
        }
        private void FillSimulationData()
        {
            _productionPlanController.FillSimulationData(_simulationType);

            // Show Grid (MWh & Time)
            if (spnlMWh.Children.Count == 1)
            {
                for (int mwh = 1500; mwh >= 0; mwh -= 50)
                {
                    TextBlock txtblockMWh = new TextBlock()
                    {
                        Text = mwh.ToString() + "-",
                        TextAlignment = TextAlignment.Right, Height = 20,
                        FontSize = 14,
                        FontFamily = FontFamily = new FontFamily("Segoe UI"),
                        FontWeight = FontWeights.Light,
                        Foreground = new SolidColorBrush(Colors.Blue)
                    };
                    spnlMWh.Children.Add(txtblockMWh);
                }
                // Time
                for (int uur = 0; uur < 24; uur++)
                {
                    TextBlock txtblockTime = new TextBlock()
                    {
                        Name = "tbl_Time_" + uur.ToString(),
                        Text = uur.ToString().Length < 2 ? "0" + uur.ToString() : uur.ToString(),
                        TextAlignment = TextAlignment.Center,
                        Width = 43,
                        FontSize = 14,
                        FontFamily = FontFamily = new FontFamily("Segoe UI"),
                        FontWeight = FontWeights.Light,
                        Margin = new Thickness(5, 0, 0, 0),
                        Foreground = new SolidColorBrush(Colors.Blue)
                    };
                    spnlTime.Children.Add(txtblockTime);
                }
            }

            // Load & Wind
            spnlLoad.Children.Clear();
            TextBlock txtblockLoadTitle = new TextBlock() 
                { Text = "Load", Width = 35, FontSize = 14, Foreground = new SolidColorBrush(Colors.Blue)};
            spnlLoad.Children.Add(txtblockLoadTitle);
            spnlWind.Children.Clear();
            TextBlock txtblockWindTitle = new TextBlock() 
                { Text = "Wind", Width = 35, FontSize = 14, Foreground = new SolidColorBrush(Colors.Blue) };
            spnlWind.Children.Add(txtblockWindTitle);
            for (int uur = 0; uur < 24; uur++)
            {
                // Load
                TextBlock txtblockLoad = new TextBlock()
                {
                    Name = "tbl_Load_" + uur.ToString(),
                    Text = _productionPlanController.Load[uur].ToString(),
                    TextAlignment = TextAlignment.Center,
                    Width = 43,
                    FontSize = 14,
                    FontFamily = FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.Light,
                    Margin = new Thickness(5, 0, 0, 0),
                    Foreground = new SolidColorBrush(Colors.White),
                    Background = _productionPlanController.Load[uur] <= 500 ? new SolidColorBrush(Colors.Green) :
                                _productionPlanController.Load[uur] <= 1000 ? new SolidColorBrush(Colors.Orange) : new SolidColorBrush(Colors.Red)
                };
                spnlLoad.Children.Add(txtblockLoad);
                // Wind
                TextBlock txtblockWind = new TextBlock()
                {
                    Name = "tbl_Wind_" + uur.ToString(),
                    Text = _productionPlanController.Wind[uur].ToString(),
                    TextAlignment = TextAlignment.Center,
                    Width = 43,
                    FontSize = 14,
                    FontFamily = FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.Light,
                    Margin = new Thickness(5, 0, 0, 0),
                    Foreground = new SolidColorBrush(Colors.White),
                    Background = _productionPlanController.Wind[uur] <= 33 ? new SolidColorBrush(Colors.LightBlue) :
                            _productionPlanController.Wind[uur] <= 66 ? new SolidColorBrush(Colors.DodgerBlue) : new SolidColorBrush(Colors.Blue)
                };
                spnlWind.Children.Add(txtblockWind);
            }
        }
        private void FillPayloadData()
        {
            _productionPlanController.FillSimulationData(_simulationType);

            // Show Grid (MWh & Time)
            if (spnlMWhPayload.Children.Count == 1)
            {
                for (int mwh = 1500; mwh >= 0; mwh -= 50)
                {
                    TextBlock txtblockMWh = new TextBlock()
                    {
                        Text = mwh.ToString() + "-",
                        TextAlignment = TextAlignment.Right,
                        Height = 20,
                        FontSize = 14,
                        FontFamily = FontFamily = new FontFamily("Segoe UI"),
                        FontWeight = FontWeights.Light,
                        Foreground = new SolidColorBrush(Colors.Blue)
                    };
                    spnlMWhPayload.Children.Add(txtblockMWh);
                }
                // Time
                int uur = 12;
                TextBlock txtblockTime = new TextBlock()
                {
                    Name = "tbl_Time_" + uur.ToString(),
                    Text = uur.ToString().Length < 2 ? "0" + uur.ToString() : uur.ToString(),
                    TextAlignment = TextAlignment.Center,
                    Width = 43,
                    FontSize = 14,
                    FontFamily = FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.Light,
                    Margin = new Thickness(5, 0, 0, 0),
                    Foreground = new SolidColorBrush(Colors.Blue)
                };
                spnlTimePayload.Children.Add(txtblockTime);
            }

            // Load & Wind
            spnlLoadPayload.Children.Clear();
            TextBlock txtblockLoadTitle = new TextBlock()
                { Text = "Load", Width = 35, FontSize = 14, Foreground = new SolidColorBrush(Colors.Blue) };
            spnlLoadPayload.Children.Add(txtblockLoadTitle);
            spnlWindPayload.Children.Clear();
            TextBlock txtblockWindTitle = new TextBlock()
            { Text = "Wind", Width = 35, FontSize = 14, Foreground = new SolidColorBrush(Colors.Blue) };
            spnlWindPayload.Children.Add(txtblockWindTitle);

            int uur12 = 0;
            // Load
            TextBlock txtblockLoad = new TextBlock()
            {
                Name = "tbl_Load_" + uur12.ToString(),
                Text = _productionPlanController.Load[uur12].ToString(),
                TextAlignment = TextAlignment.Center,
                Width = 43,
                FontSize = 14,
                FontFamily = FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.Light,
                Margin = new Thickness(5, 0, 0, 0),
                Foreground = new SolidColorBrush(Colors.White),
                Background = _productionPlanController.Load[uur12] <= 500 ? new SolidColorBrush(Colors.Green) :
                            _productionPlanController.Load[uur12] <= 1000 ? new SolidColorBrush(Colors.Orange) : new SolidColorBrush(Colors.Red)
            };
            spnlLoadPayload.Children.Add(txtblockLoad);
            // Wind
            TextBlock txtblockWind = new TextBlock()
            {
                Name = "tbl_Wind_" + uur12.ToString(),
                Text = _productionPlanController.Wind[uur12].ToString(),
                TextAlignment = TextAlignment.Center,
                Width = 43,
                FontSize = 14,
                FontFamily = FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.Light,
                Margin = new Thickness(5, 0, 0, 0),
                Foreground = new SolidColorBrush(Colors.White),
                Background = _productionPlanController.Wind[uur12] <= 33 ? new SolidColorBrush(Colors.LightBlue) :
                        _productionPlanController.Wind[uur12] <= 66 ? new SolidColorBrush(Colors.DodgerBlue) : new SolidColorBrush(Colors.Blue)
            };
            spnlWindPayload.Children.Add(txtblockWind);
        }
        private async void ShowSimulation()
        {
            for (int uur = 0; uur < 24; uur++)
            {
                Lib.ProductionPlan productionPlan = 
                    await _productionPlanController.Simulate(_productionPlanController.Load[uur], _productionPlanController.Wind[uur]);
                StackPanel stackPanel = (StackPanel)FindName("spnlData_Uur_" + uur.ToString());
                if(stackPanel != null)
                    ShowProductionPlan(stackPanel, productionPlan);
            }
        }
        private async void ShowPayload()
        {
            Lib.ProductionPlan productionPlan =
                await _productionPlanController.Simulate(_productionPlanController.Load[0], _productionPlanController.Wind[0]);
            StackPanel stackPanel = (StackPanel)FindName("spnlData_Payload");
            if (stackPanel != null)
                ShowProductionPlan(stackPanel, productionPlan);
        }
        private void ShowProductionPlan(StackPanel stackPanel, Lib.ProductionPlan productionPlan)
        {
            stackPanel.Children.Clear();
            foreach (Lib.ProductionPlanItem productionPlanItem in productionPlan.ProductionPlanItems)
            {
                if (productionPlanItem.P > 0)
                {
                    Lib.Powerplant powerplant = _productionPlanController.Powerplants
                        .Where(ppl => ppl.Name.Equals(productionPlanItem.Name, System.StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                    if (powerplant != null)
                    {
                        Color colorPowerplant = powerplant.Type.Equals("gasfired") ? Colors.Brown : powerplant.Type.Equals("turbojet") ? Colors.Red :
                                                powerplant.Type.Equals("windturbine") ? Colors.Blue : Colors.White;
                        TextBlock txtblockPowerplant = new TextBlock()
                        {
                            Text = productionPlanItem.P.ToString(),
                            Width = 43,
                            Height = 20 * productionPlanItem.P / 50,
                            Margin = new Thickness(0, 2, 0, 0),
                            Background = new SolidColorBrush(colorPowerplant),
                            FontSize = 11,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            ToolTip = new ToolTip() { Content = string.Concat(powerplant.Name, ":  ", productionPlanItem.P.ToString(), " MWh") }
                        };
                        stackPanel.Children.Add(txtblockPowerplant);
                    }
                }
            }
        }
        #endregion
        #region Constructors
        public MainWindow()
        {
            InitializeComponent();
            _productionPlanController = new ProductionPlanController(cst_url);
        }
        #endregion
        #region Event Handlers
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Initialize();
        }
        private void tbv_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sender != null && sender is TabControl)
            {
                var tabControl = sender as TabControl;
                if (tabControl.SelectedIndex == 0)
                {
                    _simulationType = enumSimulationType.NormalLoad_NormalWeather;
                    FillSimulationData();
                    ShowSimulation();
                }
                else if (tabControl.SelectedIndex == 1)
                {
                    _simulationType = enumSimulationType.PayLoad1;
                    FillPayloadData();
                    ShowPayload();
                }
            }
        }
        private void btn_NormalLoad_NormalWeather_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.NormalLoad_NormalWeather;
            FillSimulationData();
            ShowSimulation();
        }
        private void btn_NormalLoad_NoWind_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.NormalLoad_NoWind;
            FillSimulationData();
            ShowSimulation();
        }
        private void btn_NormalLoad_Storm_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.NormalLoad_Storm;
            FillSimulationData();
            ShowSimulation();
        }
        private void btn_Legende_Click(object sender, RoutedEventArgs e)
        {
            if (!popupLegende.IsOpen)
                popupLegende.IsOpen = true;
            ucTheLegende.ShowPopup();
        }
        private void btn_HeavyLoad_NormalWeather_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.HeavyLoad_NormalWeather;
            FillSimulationData();
            ShowSimulation();
        }
        private void btn_HeavyLoad_NoWind_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.HeavyLoad_NoWind;
            FillSimulationData();
            ShowSimulation();
        }
        private void btn_HeavyLoad_Storm_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.HeavyLoad_Storm;
            FillSimulationData();
            ShowSimulation();
        }
        private void btn_Payload1_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.PayLoad1;
            FillPayloadData();
            ShowPayload();
        }
        private void btn_btn_Payload2_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.PayLoad2;
            FillPayloadData();
            ShowPayload();
        }
        private void btn_btn_Payload3_Click(object sender, RoutedEventArgs e)
        {
            _simulationType = enumSimulationType.PayLoad3;
            FillPayloadData();
            ShowPayload();
        }
        #endregion
    }
}