﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
//
using Lib = ProductionPlan_Lib.Model;

namespace ProductionPlan
{
    public class ProductionPlanController
    {
        #region Private Fields
        private enumSimulationType _simulationType;
        private static readonly HttpClient _httpClient = new HttpClient();
        private string _url;
        #endregion
        #region Constructors
        public ProductionPlanController(string url)
        {
            _url = url;
            Load = new List<double>();
            Wind = new List<double>();
            Fuels = new Lib.Fuels();
            Powerplants = new List<Lib.Powerplant>();
        }
        #endregion
        #region Public Methods
        public void FillSimulationData(enumSimulationType simulationType)
        {
            _simulationType = simulationType;

            // Fill Fuels
            Fuels.Gas = 13.4;
            Fuels.Kerosine = 50.8;
            Fuels.Co2 = 20;
            Fuels.Wind = 60;

            // Fill Powerplants
            Powerplants = new List<Lib.Powerplant>();
            Powerplants.Add(new Lib.Powerplant() { Name = "gasfiredbig1", Type = "gasfired", Efficiency = 0.53, Pmin = 100, Pmax = 460, Availabilty = 100 });
            Powerplants.Add(new Lib.Powerplant() { Name = "gasfiredbig2", Type = "gasfired", Efficiency = 0.53, Pmin = 100, Pmax = 460, Availabilty = 100 });
            Powerplants.Add(new Lib.Powerplant() { Name = "gasfiredsomewhatsmaller", Type = "gasfired", Efficiency = 0.37, Pmin = 40, Pmax = 210, Availabilty = 100 });
            Powerplants.Add(new Lib.Powerplant() { Name = "tj1", Type = "turbojet", Efficiency = 0.3, Pmin = 0, Pmax = 16, Availabilty = 100 });
            Powerplants.Add(new Lib.Powerplant() { Name = "windpark1", Type = "windturbine", Efficiency = 1, Pmin = 0, Pmax = 150, Availabilty = 100 });
            Powerplants.Add(new Lib.Powerplant() { Name = "windpark2", Type = "windturbine", Efficiency = 1, Pmin = 0, Pmax = 36, Availabilty = 100 });

            // Fill Load & WindPrc
            switch (_simulationType)
            {
                case enumSimulationType.NormalLoad_NoWind:
                    {
                        Load = new List<double>() { 250, 200, 200, 200, 300, 600, 850, 750, 800, 900, 550, 500, 600, 550, 870, 600, 650, 500, 450, 400, 400, 550, 600, 800 };
                        Wind = new List<double>() { 3, 10, 5, 6, 0, 0, 0, 4, 6, 8, 10, 5, 8, 1, 0, 0, 0, 2, 5, 3, 4, 4, 4, 9 };
                        break;
                    }
                case enumSimulationType.NormalLoad_Storm:
                    {
                        Load = new List<double>() { 250, 200, 200, 200, 300, 600, 850, 750, 800, 900, 550, 500, 600, 550, 870, 600, 650, 500, 450, 400, 400, 550, 600, 800 };
                        Wind = new List<double>() { 90, 92, 100, 100, 85, 90, 85, 100, 100, 100, 100, 85, 75, 83, 80, 90, 91, 92, 85, 80, 70, 88, 100, 90 };
                        break;
                    }
                case enumSimulationType.HeavyLoad_NormalWeather:
                    {
                        Load = new List<double>() { 850, 800, 800, 800, 900, 1200, 1450, 1350, 1400, 1450, 1150, 1100, 1200, 1150, 1470, 1200, 1250, 1100, 1050, 1000, 1000, 1150, 1200, 1400 };
                        Wind = new List<double>() { 40, 52, 45, 50, 45, 40, 45, 55, 40, 40, 32, 40, 28, 41, 8, 34, 33, 34, 25, 28, 30, 20, 25, 33 };
                        break;
                    }
                case enumSimulationType.HeavyLoad_NoWind:
                    {
                        Load = new List<double>() { 850, 800, 800, 800, 900, 1200, 1450, 1350, 1400, 1450, 1150, 1100, 1200, 1150, 1470, 1200, 1250, 1100, 1050, 1000, 1000, 1150, 1200, 1400 };
                        Wind = new List<double>() { 3, 10, 5, 6, 0, 0, 0, 4, 6, 8, 10, 5, 8, 1, 0, 0, 0, 2, 5, 3, 4, 4, 4, 9 };
                        break;
                    }
                case enumSimulationType.HeavyLoad_Storm:
                    {
                        Load = new List<double>() { 850, 800, 800, 800, 900, 1200, 1450, 1350, 1400, 1450, 1150, 1100, 1200, 1150, 1470, 1200, 1250, 1100, 1050, 1000, 1000, 1150, 1200, 1400 };
                        Wind = new List<double>() { 90, 92, 100, 100, 85, 90, 85, 100, 100, 100, 100, 85, 75, 83, 80, 90, 91, 92, 85, 80, 70, 88, 100, 90 };
                        break;
                    }
                case enumSimulationType.PayLoad1:
                    {
                        Load = new List<double>() { 480 };
                        Wind = new List<double>() { 60};
                        break;
                    }
                case enumSimulationType.PayLoad2:
                    {
                        Load = new List<double>() { 480 };
                        Wind = new List<double>() { 0 };
                        break;
                    }
                case enumSimulationType.PayLoad3:
                    {
                        Load = new List<double>() { 910 };
                        Wind = new List<double>() { 60 };
                        break;
                    }
                default: // NormalLoad_NormalWeather
                    {
                        Load = new List<double>() { 250, 200, 200, 200, 300, 600, 850, 750, 800, 900, 550, 500, 600, 550, 870, 600, 650, 500, 450, 400, 400, 550, 600, 800 };
                        Wind = new List<double>() { 40, 52, 45, 50, 45, 40, 45, 55, 40, 40, 32, 40, 28, 41, 8, 34, 33, 34, 25, 28, 30, 20, 25, 33 };
                        break;
                    }
            }
        }
        public async Task<Lib.ProductionPlan> Simulate(double load, double wind)
        {
            Lib.ProductionPlan productionPlan = new Lib.ProductionPlan() { ProductionPlanItems = new List<Lib.ProductionPlanItem>() };

            Fuels.Wind = wind;
            Lib.Payload payload = new Lib.Payload() { Load = load, Fuels = Fuels, PowerPlants = Powerplants };

            try
            {
                var payloadJson = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
                HttpResponseMessage httpResponse = await _httpClient.PostAsync(new Uri(_url), payloadJson);
                if (httpResponse.IsSuccessStatusCode)
                {
                    string responseBody = await httpResponse.Content.ReadAsStringAsync();
                    string json = string.Concat(@"{""productionplanitems"" : [", responseBody.Substring(1), "}");
                    productionPlan = JsonSerializer.Deserialize<Lib.ProductionPlan>(json);
                }
            }
            catch { }

            return productionPlan;
        }
        #endregion
        #region Public Properties
        public List<double> Load { get; set; }
        public List<double> Wind { get; set; }
        public Lib.Fuels Fuels { get; set; }
        public List<Lib.Powerplant> Powerplants { get; set; }
        #endregion
    }

    public enum enumSimulationType
    {
        NormalLoad_NormalWeather = 0,
        NormalLoad_NoWind = 1,
        NormalLoad_Storm = 2,
        HeavyLoad_NormalWeather = 3,
        HeavyLoad_NoWind = 4,
        HeavyLoad_Storm = 5,
        PayLoad1 = 6,
        PayLoad2 = 7,
        PayLoad3 = 8
    }
}
