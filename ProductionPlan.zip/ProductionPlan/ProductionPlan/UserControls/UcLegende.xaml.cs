﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProductionPlan.UserControls
{
    public partial class UcLegende : UserControl
    {
        #region Constructors
        public UcLegende()
        {
            InitializeComponent();
        }
        #endregion
        #region Event Handlers
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Grid grd = this.Parent as Grid;
            if (grd != null)
            {
                Popup p = grd.Parent as Popup;
                if (p != null)
                    p.IsOpen = false;
            }
        }
        #endregion
        #region Public Members
        public void ShowPopup()
        {
        }
        #endregion
    }
}