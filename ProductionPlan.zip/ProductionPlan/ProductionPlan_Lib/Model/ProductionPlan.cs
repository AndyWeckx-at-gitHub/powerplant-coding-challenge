﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ProductionPlan_Lib.Model
{
    public sealed class ProductionPlan
    {
        #region Public Properties
        [JsonPropertyName("id")] 
        public int Id { get; set; }
        [JsonPropertyName("productionplanitems")] 
        public List<ProductionPlanItem> ProductionPlanItems { get; set; }
        [JsonPropertyName("result")] 
        public string Result { get; set; }
        #endregion
    }
}
