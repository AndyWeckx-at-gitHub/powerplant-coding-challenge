﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProductionPlan_Lib.Model
{
    public class Powerplant
    {
        #region Public Methods
        public override string ToString()
        {
            return string.Concat("Name:  ", Name, "    Type:  ", Type, "    Cost:  ", CostToGeneratePower.ToString(), " EUR");
        }
        #endregion
        #region Public Properties
        public string Name { get; set; }
        public string Type { get; set; } 
        public double Efficiency { get; set; }
        public double Pmin { get; set; }
        public double Pmax { get; set; }

        public double CostToGeneratePower { get; set; }
        public double CostFuel { get; set; }
        public double CostCo2 { get; set; }
        public double CreatedCo2 { get; set; }
        public double Availabilty { get; set; }
        #endregion
    }
}