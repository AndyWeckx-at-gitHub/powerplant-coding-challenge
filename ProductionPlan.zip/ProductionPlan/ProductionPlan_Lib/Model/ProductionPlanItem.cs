﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ProductionPlan_Lib.Model
{
    public sealed class ProductionPlanItem
    {
        #region Public Methods
        public override string ToString()
        {
            return string.Concat("Name:  ", Name, "    Power:  ", P.ToString(), " MWh");
        }
        #endregion
        #region Public Properties
        [JsonPropertyName("name")] 
        public string Name { get; set; }
        [JsonPropertyName("p")] 
        public double P { get; set; }
        #endregion
    }
}
